# Image Processing API Project

## Overview
This project help you to resize the images and cache it. 

## Instructions
You can resize the image by two method:
### Method 1:
Write the url to resizing page contains the required parameters (name, width, height ) ex:-
`http://localhost:3000/resizeImage?name=fjord.jpg&width=200&height=200`

### Method 2:
##### step 1: goto url http://localhost:3000/
##### step 2: fill the inputs (Image name, Image width , Image Height)
please not: image name must be one of the image that exist in *src/website/images* dir.


